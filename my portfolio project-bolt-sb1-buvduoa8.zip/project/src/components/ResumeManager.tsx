import React, { useState } from 'react';
import { X, Upload, Download, FileText, Trash2, Save } from 'lucide-react';

interface Resume {
  id: string;
  name: string;
  uploadDate: string;
  fileSize: string;
  isActive: boolean;
}

interface ResumeManagerProps {
  onClose: () => void;
}

export const ResumeManager: React.FC<ResumeManagerProps> = ({ onClose }) => {
  const [resumes, setResumes] = useState<Resume[]>([
    {
      id: '1',
      name: 'MONDETI_SAI_VIKAS_Resume_2024.pdf',
      uploadDate: '2024-01-15',
      fileSize: '2.3 MB',
      isActive: true
    }
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newResume: Resume = {
        id: Date.now().toString(),
        name: file.name,
        uploadDate: new Date().toISOString().split('T')[0],
        fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        isActive: false
      };
      setResumes([...resumes, newResume]);
    }
  };

  const setActiveResume = (id: string) => {
    setResumes(resumes.map(resume => ({
      ...resume,
      isActive: resume.id === id
    })));
  };

  const deleteResume = (id: string) => {
    setResumes(resumes.filter(resume => resume.id !== id));
  };

  const downloadResume = (resume: Resume) => {
    alert(`Downloading ${resume.name}...`);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 p-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-800">Resume Manager</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Upload Section */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Upload New Resume</h3>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-blue-600" />
              </div>
              <h4 className="text-lg font-medium text-slate-800 mb-2">Upload Resume</h4>
              <p className="text-slate-600 mb-4">Drag and drop your resume file or click to browse</p>
              <label className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 cursor-pointer inline-flex items-center space-x-2">
                <Upload className="w-4 h-4" />
                <span>Choose File</span>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              <p className="text-sm text-slate-500 mt-2">Supported formats: PDF, DOC, DOCX (Max 10MB)</p>
            </div>
          </div>

          {/* Resume List */}
          <div>
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Manage Resumes</h3>
            <div className="space-y-4">
              {resumes.map((resume) => (
                <div key={resume.id} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="bg-red-100 p-3 rounded-lg">
                        <FileText className="w-6 h-6 text-red-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-800">{resume.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-slate-500">
                          <span>Uploaded: {new Date(resume.uploadDate).toLocaleDateString()}</span>
                          <span>Size: {resume.fileSize}</span>
                          {resume.isActive && (
                            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                              Active
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {!resume.isActive && (
                        <button
                          onClick={() => setActiveResume(resume.id)}
                          className="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 text-sm"
                        >
                          Set Active
                        </button>
                      )}
                      <button
                        onClick={() => downloadResume(resume)}
                        className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteResume(resume.id)}
                        className="bg-red-600 text-white p-2 rounded-lg hover:bg-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Info Section */}
          <div className="mt-8 bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Resume Management Tips</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Keep multiple versions of your resume for different job applications</li>
              <li>• Set one resume as "Active" - this will be used for the download button on your portfolio</li>
              <li>• Update your resume regularly to reflect your latest projects and skills</li>
              <li>• Use descriptive filenames to easily identify different versions</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};