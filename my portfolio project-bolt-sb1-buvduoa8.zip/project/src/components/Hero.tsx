import React from 'react';
import { Download, MapPin, Mail, Phone, Linkedin, Edit3 } from 'lucide-react';
import { Profile } from '../types';

interface HeroProps {
  profile: Profile;
  isAuthenticated: boolean;
  onEditProfile: () => void;
}

export const Hero: React.FC<HeroProps> = ({ profile, isAuthenticated, onEditProfile }) => {
  return (
    <section className="bg-gradient-to-br from-blue-50 to-slate-100 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <div className="relative">
              <img
                src={profile.photo}
                alt={profile.name}
                className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover shadow-lg mx-auto lg:mx-0 border-4 border-white"
              />
              {isAuthenticated && (
                <button
                  onClick={onEditProfile}
                  className="absolute -top-2 -right-2 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors duration-200 shadow-lg"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              )}
            </div>
            
            <div className="text-center lg:text-left mt-6">
              <h1 className="text-4xl md:text-5xl font-bold text-slate-800 mb-2">
                {profile.name}
              </h1>
              <p className="text-xl md:text-2xl text-blue-600 font-medium mb-4">
                {profile.title}
              </p>
              <p className="text-slate-600 mb-6 max-w-2xl">
                {profile.bio}
              </p>
              
              <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-6">
                <div className="flex items-center space-x-2 text-slate-600">
                  <MapPin className="w-4 h-4" />
                  <span>{profile.contact.location}</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-600">
                  <Mail className="w-4 h-4" />
                  <span>{profile.contact.email}</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-600">
                  <Phone className="w-4 h-4" />
                  <span>{profile.contact.phone}</span>
                </div>
              </div>

              <div className="flex flex-wrap justify-center lg:justify-start gap-4">
                <button 
                  onClick={() => alert('Resume download functionality would be implemented here.')}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center space-x-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Resume</span>
                </button>
                <a
                  href={`https://${profile.contact.linkedin}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white text-blue-600 border-2 border-blue-600 px-6 py-3 rounded-lg hover:bg-blue-600 hover:text-white transition-colors duration-200 flex items-center space-x-2"
                >
                  <Linkedin className="w-4 h-4" />
                  <span>LinkedIn</span>
                </a>
                {isAuthenticated && (
                  <button
                    onClick={() => alert('Resume manager functionality would be implemented here.')}
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center space-x-2"
                  >
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 lg:pl-12">
            <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
              <h3 className="text-2xl font-bold text-slate-800 mb-6">Skills & Expertise</h3>
              <div className="grid grid-cols-2 gap-4 mb-6">
                {profile.skills.map((skill, index) => (
                  <div key={index} className="bg-blue-50 text-blue-800 px-3 py-2 rounded-lg text-center font-medium">
                    {skill}
                  </div>
                ))}
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-800 mb-2">Experience</h4>
                  <p className="text-slate-600">{profile.experience}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-slate-800 mb-2">Education</h4>
                  <p className="text-slate-600">{profile.education}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};