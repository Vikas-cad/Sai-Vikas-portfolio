import React from 'react';
import { Calendar, Download, Eye, FileText, Cuboid as Cube, Edit3 } from 'lucide-react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
  onViewProject: (project: Project) => void;
  onEditProject?: (project: Project) => void;
  isAuthenticated?: boolean;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ 
  project, 
  onViewProject, 
  onEditProject, 
  isAuthenticated = false 
}) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative">
        <img
          src={project.thumbnail}
          alt={project.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
            {project.category}
          </span>
        </div>
        {isAuthenticated && onEditProject && (
          <button
            onClick={() => onEditProject(project)}
            className="absolute top-4 right-4 bg-white text-slate-600 p-2 rounded-full hover:bg-slate-100 shadow-lg"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-slate-800 mb-2">{project.title}</h3>
        <p className="text-slate-600 mb-4 line-clamp-3">{project.description}</p>

        <div className="flex flex-wrap gap-2 mb-4">
          {project.tags.map((tag, index) => (
            <span
              key={index}
              className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-sm"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 text-sm text-slate-500">
            <div className="flex items-center space-x-1">
              <Cube className="w-4 h-4" />
              <span>{project.cadFiles.length} CAD Files</span>
            </div>
            <div className="flex items-center space-x-1">
              <FileText className="w-4 h-4" />
              <span>{project.documents.length} Docs</span>
            </div>
          </div>
          <div className="flex items-center space-x-1 text-sm text-slate-500">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(project.updatedAt)}</span>
          </div>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => onViewProject(project)}
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Eye className="w-4 h-4" />
            <span>View Project</span>
          </button>
          {isAuthenticated && onEditProject && (
            <button
              onClick={() => onEditProject(project)}
              className="bg-slate-600 text-white py-2 px-4 rounded-lg hover:bg-slate-700 transition-colors duration-200 flex items-center justify-center"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};