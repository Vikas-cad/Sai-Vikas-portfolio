import { Project, Profile } from '../types';

export const profile: Profile = {
  name: "MONDETI SAI VIKAS",
  title: " Design Engineer",
  photo: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
  bio: "I’m a Mechanical Engineer with hands-on experience in CATIA V5, specializing in plastic trim design for automotive interiors and exteriors. I’ve worked on real-world projects like door panels, bumpers, and cup holders using Part Design, Surface Design, and Remastering techniques.Certified in AutoCAD, SolidWorks, and Robotics (NPTEL), I’ve completed a 6-month internship on CATIA and trained under Skill India and DDUGKY. I’m hardworking, quick to learn, and ready to contribute to innovative product development teams..",
  skills: ["Catia V5", "3D Modeling", "Generative Shape Design", "Remastering", "Plastic Trims", "Interior & Exterior Trims", "Solidworks", "AutoCAD", "Drafting", "Class A Surface"],
  experience: "6+ months of experience in automotive and aerospace design",
  education: "Bachelor of Technology in Mechanical Engineering",
  contact: {
    email: "saivmodeti2002@gmail.com",
    phone: "+91 72072 866252",
    location: "Vijayawada, AP, India",
    linkedin: "https://www.linkedin.com/in/sai-vikas-mondeti-36301026a/"
  }
};

export const projects: Project[] = [
  {
    id: "1",
    title: "Automotive Engine Component Design",
    description: "Complete design and modeling of automotive engine components including pistons, connecting rods, and cylinder heads using Catia V5.",
    category: "Automotive",
    tags: ["Engine Design", "Automotive", "3D Modeling", "Simulation"],
    thumbnail: "https://images.pexels.com/photos/279949/pexels-photo-279949.jpeg?auto=compress&cs=tinysrgb&w=600",
    images: [
      "https://images.pexels.com/photos/279949/pexels-photo-279949.jpeg?auto=compress&cs=tinysrgb&w=800",
      "https://images.pexels.com/photos/1118448/pexels-photo-1118448.jpeg?auto=compress&cs=tinysrgb&w=800"
    ],
    cadFiles: [
      { name: "engine_piston.CATPart", format: "CATPart", size: "2.5 MB", downloadUrl: "#" },
      { name: "connecting_rod.CATPart", format: "CATPart", size: "1.8 MB", downloadUrl: "#" },
      { name: "engine_assembly.CATProduct", format: "CATProduct", size: "8.2 MB", downloadUrl: "#" }
    ],
    documents: [
      { name: "Design_Specifications.pdf", type: "PDF", downloadUrl: "#" },
      { name: "Technical_Drawings.pdf", type: "PDF", downloadUrl: "#" }
    ],
    createdAt: "2024-01-15",
    updatedAt: "2024-01-20"
  },
  {
    id: "2",
    title: "Aerospace Wing Structure",
    description: "Design and analysis of aircraft wing structural components with focus on weight optimization and stress distribution.",
    category: "Aerospace",
    tags: ["Aerospace", "Structural Design", "Weight Optimization", "Analysis"],
    thumbnail: "https://images.pexels.com/photos/358319/pexels-photo-358319.jpeg?auto=compress&cs=tinysrgb&w=600",
    images: [
      "https://images.pexels.com/photos/358319/pexels-photo-358319.jpeg?auto=compress&cs=tinysrgb&w=800"
    ],
    cadFiles: [
      { name: "wing_structure.CATPart", format: "CATPart", size: "4.1 MB", downloadUrl: "#" },
      { name: "wing_assembly.CATProduct", format: "CATProduct", size: "12.5 MB", downloadUrl: "#" }
    ],
    documents: [
      { name: "Stress_Analysis_Report.pdf", type: "PDF", downloadUrl: "#" },
      { name: "Design_Calculations.xlsx", type: "Excel", downloadUrl: "#" }
    ],
    createdAt: "2024-02-10",
    updatedAt: "2024-02-15"
  },
  {
    id: "3",
    title: "Industrial Machinery Design",
    description: "Custom industrial machinery design for manufacturing processes, including conveyor systems and automated equipment.",
    category: "Industrial",
    tags: ["Industrial Design", "Automation", "Manufacturing", "Machinery"],
    thumbnail: "https://images.pexels.com/photos/1108101/pexels-photo-1108101.jpeg?auto=compress&cs=tinysrgb&w=600",
    images: [
      "https://images.pexels.com/photos/1108101/pexels-photo-1108101.jpeg?auto=compress&cs=tinysrgb&w=800"
    ],
    cadFiles: [
      { name: "conveyor_system.CATProduct", format: "CATProduct", size: "6.8 MB", downloadUrl: "#" },
      { name: "automation_unit.CATPart", format: "CATPart", size: "3.2 MB", downloadUrl: "#" }
    ],
    documents: [
      { name: "Manufacturing_Guide.pdf", type: "PDF", downloadUrl: "#" },
      { name: "Assembly_Instructions.pdf", type: "PDF", downloadUrl: "#" }
    ],
    createdAt: "2024-03-05",
    updatedAt: "2024-03-12"
  }
];