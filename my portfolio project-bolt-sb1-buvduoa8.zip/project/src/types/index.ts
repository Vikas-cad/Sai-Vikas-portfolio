export interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  thumbnail: string;
  images: string[];
  cadFiles: {
    name: string;
    format: string;
    size: string;
    downloadUrl: string;
  }[];
  documents: {
    name: string;
    type: string;
    downloadUrl: string;
  }[];
  createdAt: string;
  updatedAt: string;
}

export interface Profile {
  name: string;
  title: string;
  photo: string;
  bio: string;
  skills: string[];
  experience: string;
  education: string;
  contact: {
    email: string;
    phone: string;
    location: string;
    linkedin: string;
  };
}