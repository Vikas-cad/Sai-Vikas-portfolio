import React, { useState } from 'react';
import { Plus, Settings } from 'lucide-react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProjectCard } from './components/ProjectCard';
import { ProjectDetail } from './components/ProjectDetail';
import { ProjectUpload } from './components/ProjectUpload';
import { ProjectEditor } from './components/ProjectEditor';
import { ProfileEditor } from './components/ProfileEditor';
import { ResumeManager } from './components/ResumeManager';
import { AuthModal } from './components/AuthModal';
import { ContactSection } from './components/ContactSection';
import { profile, projects as initialProjects } from './data/mockData';
import { Project } from './types';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showProfileEditor, setShowProfileEditor] = useState(false);
  const [showResumeManager, setShowResumeManager] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState(initialProjects);
  const [currentProfile, setCurrentProfile] = useState(profile);

  const handleAuthentication = (password: string) => {
    if (password === 'Saivikas@2002') {
      setIsAuthenticated(true);
      setShowAuthModal(false);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleProjectSave = (projectData: any) => {
    const newProject: Project = {
      ...projectData,
      id: Date.now().toString()
    };
    setProjects([newProject, ...projects]);
    setShowUploadModal(false);
    alert('Project uploaded successfully!');
  };

  const handleProjectUpdate = (updatedProject: Project) => {
    setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
    setEditingProject(null);
    alert('Project updated successfully!');
  };

  const handleProjectDelete = (projectId: string) => {
    setProjects(projects.filter(p => p.id !== projectId));
    setEditingProject(null);
    alert('Project deleted successfully!');
  };

  const handleProfileUpdate = (updatedProfile: typeof profile) => {
    setCurrentProfile(updatedProfile);
    setShowProfileEditor(false);
    alert('Profile updated successfully!');
  };

  const handleEditProfile = () => {
    if (isAuthenticated) {
      setShowProfileEditor(true);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header 
        onAuthClick={() => setShowAuthModal(true)}
        isAuthenticated={isAuthenticated}
        onLogout={handleLogout}
      />
      
      <main>
        {/* Hero Section */}
        <section id="about">
          <Hero 
            profile={currentProfile}
            isAuthenticated={isAuthenticated}
            onEditProfile={handleEditProfile}
          />
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
                  Featured Projects
                </h2>
                <p className="text-xl text-slate-600">
                  Explore my latest work in Catia V5 design and engineering
                </p>
              </div>
              
              {isAuthenticated && (
                <div className="flex space-x-4">
                  <button
                    onClick={() => setShowResumeManager(true)}
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center space-x-2 shadow-lg"
                  >
                    <Settings className="w-5 h-5" />
                    <span>Resume Manager</span>
                  </button>
                  <button
                    onClick={() => setShowUploadModal(true)}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center space-x-2 shadow-lg"
                  >
                    <Plus className="w-5 h-5" />
                    <span>Upload Project</span>
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onViewProject={setSelectedProject}
                  onEditProject={setEditingProject}
                  isAuthenticated={isAuthenticated}
                />
              ))}
            </div>

            {projects.length === 0 && (
              <div className="text-center py-20">
                <div className="bg-slate-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Plus className="w-12 h-12 text-slate-400" />
                </div>
                <h3 className="text-xl font-semibold text-slate-800 mb-2">No Projects Yet</h3>
                <p className="text-slate-600 mb-6">Start by uploading your first project to showcase your work.</p>
                {isAuthenticated && (
                  <button
                    onClick={() => setShowUploadModal(true)}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    Upload First Project
                  </button>
                )}
              </div>
            )}
          </div>
        </section>

        {/* Contact Section */}
        <ContactSection profile={currentProfile} />
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2024 {currentProfile.name}. All rights reserved.</p>
          <p className="text-slate-400 mt-2">Catia V5 Design Engineer Portfolio</p>
        </div>
      </footer>

      {/* Modals */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onAuthenticate={handleAuthentication}
        />
      )}

      {showProfileEditor && (
        <ProfileEditor
          profile={currentProfile}
          onClose={() => setShowProfileEditor(false)}
          onSave={handleProfileUpdate}
        />
      )}

      {showResumeManager && (
        <ResumeManager
          onClose={() => setShowResumeManager(false)}
        />
      )}

      {showUploadModal && (
        <ProjectUpload
          onClose={() => setShowUploadModal(false)}
          onSave={handleProjectSave}
        />
      )}

      {editingProject && (
        <ProjectEditor
          project={editingProject}
          onClose={() => setEditingProject(null)}
          onSave={handleProjectUpdate}
          onDelete={handleProjectDelete}
        />
      )}

      {selectedProject && (
        <ProjectDetail
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
        />
      )}
    </div>
  );
}

export default App;